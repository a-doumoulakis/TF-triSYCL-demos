/**
 *  Copyright (C) 2015-2016 Xilinx, Inc. All rights reserved.
 *  Author: Sonal Santan
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 */

#include <linux/module.h>
#include <linux/cdev.h>
#include <linux/delay.h>
#include <linux/uaccess.h>
#include <linux/fs.h>
#include <linux/io.h>
#include <linux/kernel.h>
#include <linux/firmware.h>
#include <linux/pci.h>
#include <linux/vmalloc.h>


#include "xdma-core.h"
#include "xdma-ioctl.h"
#include "xbar_sys_parameters.h"

#define MULTFRAC_BUG 1

/*
 * Precomputed table with config0 and config2 register values
 * together with target frequency. The steps are 20 MHz apart.
 */

const static struct xdma_ocl_clockwiz frequency_table[] = {
		{  20, 0x0101, 0x0005},
		{  40, 0x0201, 0x0005},
		{  60, 0x0301, 0x0005},
		{  80, 0x0401, 0x0005},
		{ 100, 0x0501, 0x0005},
		{ 120, 0x0601, 0x0005},
		{ 140, 0x0701, 0x0005},
		{ 160, 0x0801, 0x0005},
		{ 180, 0x0901, 0x0005},
		{ 200, 0x0a01, 0x0005},
		{ 220, 0x0b01, 0x0005},
		{ 240, 0x0c01, 0x0005},
		{ 260, 0x0d01, 0x0005},
		{ 280, 0x0e01, 0x0005},
		{ 300, 0x0f01, 0x0005},
		{ 320, 0x1001, 0x0005},
		{ 340, 0x1101, 0x0005},
		{ 360, 0x1201, 0x0005},
		{ 380, 0x1301, 0x0005},
		{ 400, 0x1401, 0x0005}
};

static int reinit(struct xdma_dev *lro)
{
	int rc = 0;
	int dir_from_dev;
	int channel;
	struct xdma_engine *engine = NULL;

	/* Renable the interrupts */
	rc = interrupts_enable(lro, XDMA_OFS_INT_CTRL, 0x00ffffffUL);
	for (dir_from_dev = 0; dir_from_dev < 2; dir_from_dev++) {
		/* Re-init all the channels */
		for (channel = 0; channel < XDMA_CHANNEL_NUM_MAX; channel++) {
			engine = lro->engine[channel][dir_from_dev];
			if (engine)
				engine_reinit(engine);
		}
	}
	return rc;
}


static unsigned compute_unit_busy(struct xdma_dev *lro)
{
	int i = 0;
	unsigned result = 0;
	u32 r = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);

	/* r != 0x3 implies that OCL region is isolated and we cannot read CUs' status */
	if (r != 0x3)
	    return 0;

	for (i = 0; i < 16; i++) {
		r = ioread32(lro->bar[USER_BAR] + OCL_CTLR_OFFSET + i * OCL_CU_CTRL_RANGE);
		if (r == 0x1)
		    result |= (r << i);
	}
	return result;
}


void freezeAXIGate(struct xdma_dev *lro)
{
	u8 w = 0x0;
	u32 t;

	BUG_ON(lro->axi_gate_frozen);
//	printk(KERN_DEBUG "IOCTL %s:%d\n", __FILE__, __LINE__);
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	iowrite8(w, lro->bar[USER_BAR] + AXI_GATE_OFFSET);
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	lro->axi_gate_frozen = 1;
	printk(KERN_DEBUG "%s: Froze AXI gate\n", DRV_NAME);
}

void freeAXIGate(struct xdma_dev *lro)
{
	/*
	 * First pulse the OCL RESET. This is important for PR with multiple
	 * clocks as it resets the edge triggered clock converter FIFO
	 */
	u8 w = 0x2;
	u32 t;

	BUG_ON(!lro->axi_gate_frozen);
//	printk(KERN_DEBUG "IOCTL %s:%d\n", __FILE__, __LINE__);
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	iowrite8(w, lro->bar[USER_BAR] + AXI_GATE_OFFSET);
	ndelay(500);

	w = 0x0;
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	iowrite8(w, lro->bar[USER_BAR] + AXI_GATE_OFFSET);
	ndelay(500);

	w = 0x2;
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	iowrite8(w, lro->bar[USER_BAR] + AXI_GATE_OFFSET);
	ndelay(500);

	w = 0x3;
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	iowrite8(w, lro->bar[USER_BAR] + AXI_GATE_OFFSET);
	ndelay(500);
	t = ioread32(lro->bar[USER_BAR] + AXI_GATE_OFFSET_READ);
//	printk("Register %x\n", t);
	lro->axi_gate_frozen = 0;
	printk(KERN_DEBUG "%s: Un-froze AXI gate\n", DRV_NAME);
}

static unsigned get_ocl_frequency(const struct xdma_dev *lro)
{
	u32 val;
	const u64 input = (lro->pci_dev->device == 0x8138) ? XDMA_KU3_INPUT_FREQ : XDMA_7V3_INPUT_FREQ;
	u32 mul0, div0;
	u32 mul_frac0 = 0;
	u32 div1;
	u32 div_frac1 = 0;
	u64 freq;

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_STATUS);
	printk(KERN_DEBUG "%s: ClockWiz SR %x\n", DRV_NAME, val);
	if ((val & 1) == 0)
		return 0;

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(0));
	printk(KERN_DEBUG "%s: ClockWiz CONFIG(0) %x\n", DRV_NAME, val);

	div0 = val & 0xff;
	mul0 = (val & 0xff00) >> 8;
	if (val & BIT(26)) {
		mul_frac0 = val >> 16;
		mul_frac0 &= 0x3ff;
	}

	/*
	 * Multiply both numerator (mul0) and the denominator (div0) with 1000 to
	 * account for fractional portion of multiplier
	 */
	mul0 *= 1000;
	mul0 += mul_frac0;
	div0 *= 1000;

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(2));
	printk(KERN_DEBUG "%s: ClockWiz CONFIG(2) %x\n", DRV_NAME, val);
	div1 = val &0xff;
	if (val & BIT(18)) {
		div_frac1 = val >> 8;
		div_frac1 &= 0x3ff;
	}

	/*
	 * Multiply both numerator (mul0) and the denominator (div1) with 1000 to
	 * account for fractional portion of divider
	 */

	div1 *= 1000;
	div1 += div_frac1;
        printk(KERN_DEBUG "%s: CLKOUT0_DIVIDE_F %d\n", DRV_NAME, div1);
        printk(KERN_DEBUG "%s: CLKFBOUT_MULT_F %d\n", DRV_NAME, mul0);
        printk(KERN_DEBUG "%s: DIVCLK_DIVIDE %d\n", DRV_NAME, div0);
	div0 *= div1;
	mul0 *= 1000;
	if (div0 == 0) {
		printk(KERN_ERR "%s: ClockWiz Invalid divider 0\n", DRV_NAME);
		return 0;
	}
	freq = (input * mul0)/div0;
	printk(KERN_DEBUG "%s: ClockWiz OCL Frequency %lld\n", DRV_NAME, freq);
	return freq;
}

static int pcie_link_info(const struct xdma_dev *lro, struct xdma_ioc_info *obj)
{
    u16 stat;
    long result;

    obj->pcie_link_width = 0;
    obj->pcie_link_speed = 0;
    result = pcie_capability_read_word(lro->pci_dev, PCI_EXP_LNKSTA, &stat);
    if (result)
        return result;
    obj->pcie_link_width = (stat & PCI_EXP_LNKSTA_NLW) >> PCI_EXP_LNKSTA_NLW_SHIFT;
    obj->pcie_link_speed = stat & PCI_EXP_LNKSTA_CLS;
    return 0;
}

int device_info(const struct xdma_dev *lro, struct xdma_ioc_info *obj)
{
	memset(obj, 0, sizeof(struct xdma_ioc_info));
	obj->vendor = lro->pci_dev->vendor;
	obj->device = lro->pci_dev->device;
	obj->subsystem_vendor = lro->pci_dev->subsystem_vendor;
	obj->subsystem_device = lro->pci_dev->subsystem_device;
	obj->feature_id = lro->feature_id;
	obj->driver_version = XDMA_DRIVER_MAJOR * 100 + XDMA_DRIVER_MINOR * 10 + XDMA_DRIVER_PATCHLEVEL;
	obj->ocl_frequency = get_ocl_frequency(lro);
	return pcie_link_info(lro, obj);
}

static long version_ioctl(struct xdma_char *lro_char, void __user *arg)
{
	struct xdma_ioc_info obj;
	struct xdma_dev *lro = lro_char->lro;
        int err = device_info(lro, &obj);
	if (copy_to_user(arg, &obj, sizeof(struct xdma_ioc_info)))
		return -EFAULT;
	return err;
}

static long reset_ocl_ioctl(struct xdma_char *lro_char)
{
	struct xdma_dev *lro = lro_char->lro;

	/* If compute units are not busy then nothing to do */
	if (!compute_unit_busy(lro))
		return 0;

	freezeAXIGate(lro);
	freeAXIGate(lro);
	return compute_unit_busy(lro) ? -EBUSY : 0;
}


/*
 * pcie_(un)mask_surprise_down inspired by myri10ge driver, myri10ge.c
 */

static int pcie_mask_surprise_down(struct pci_dev *pdev, u32 *orig_mask)
{
	struct pci_dev *bridge = pdev->bus->self;
	int cap;
	u32 mask;

	if (bridge == NULL)
		return 1;

	cap = pci_find_ext_capability(bridge, PCI_EXT_CAP_ID_ERR);
	if (cap) {
		pci_read_config_dword(bridge, cap + PCI_ERR_UNCOR_MASK, orig_mask);
		mask = *orig_mask;
		mask |= 0x20;
		pci_write_config_dword(bridge, cap + PCI_ERR_UNCOR_MASK, mask);
		return 0;
	}
	return 1;
}


static int pcie_unmask_surprise_down(struct pci_dev *pdev, u32 orig_mask)
{
	struct pci_dev *bridge = pdev->bus->self;
	int cap;

	if (bridge == NULL)
		return 1;

	cap = pci_find_ext_capability(bridge, PCI_EXT_CAP_ID_ERR);
	if (cap) {
		pci_write_config_dword(bridge, cap + PCI_ERR_UNCOR_MASK, orig_mask);
		return 0;
	}
	return 1;
}


/*
 * Inspired by GenWQE driver, card_base.c
 */

static int pci_fundamental_reset(struct xdma_dev *lro)
{
	int rc;
	u32 orig_mask;
	struct pci_dev *pci_dev = lro->pci_dev;

	/*
	 * lock pci config space access from userspace,
	 * save state and issue PCIe fundamental reset
	 */
	pci_cfg_access_lock(pci_dev);
	pci_save_state(pci_dev);
	rc = pcie_mask_surprise_down(pci_dev, &orig_mask);
	if (rc)
		goto done;

#if defined(__PPC64__)
	/*
	 * On PPC64LE use pcie_warm_reset which will cause the FPGA to
	 * reload from PROM
	 */
	rc = pci_set_pcie_reset_state(pci_dev, pcie_warm_reset);
	if (rc)
		goto done;
	/* keep PCIe reset asserted for 250ms */
	msleep(250);
	rc = pci_set_pcie_reset_state(pci_dev, pcie_deassert_reset);
	if (rc)
		goto done;
	/* Wait for 2s to reload flash and train the link */
	msleep(2000);
#else
	/*
	 * On x86_64 use special bitstream sequence which forces the FPGA to
	 * reload from PROM
	 */
	rc = load_reset_mini_bitstream(lro);
	if (rc)
		goto done;
#endif
done:
	pci_restore_state(pci_dev);
	rc = pcie_unmask_surprise_down(pci_dev, orig_mask);
	pci_cfg_access_unlock(pci_dev);
	reinit(lro);
	return rc;
}


/**
 * Simple implementation of device reset using PCIe hot reset
 * Toggle a special bit in the PCI_MIN_GNT config byte of connected
 * root port to reset the card except for the EP which stays up.
 * There is no support yet for quashing any pending DMA transactions,
 * and returning EIO for pending DMA read/writes, etc. More features
 * will be added incrementally. Note this does not reset the PCIe link.
 */

static long reset_hot_ioctl(struct xdma_char *lro_char)
{
	u32 *pci_cfg = NULL;
	u32 pci_cfg2[0x40];
	u8 hot;
	int i;
	long err = 0;
	const char *ep_name;
	const char *rp_name;
	struct xdma_dev *lro = lro_char->lro;
	struct pci_dev *pdev = lro->pci_dev;

	BUG_ON(!pdev->bus);
	BUG_ON(!pdev->bus->self);

	if (!pdev->bus || !pdev->bus->self) {
		printk(KERN_ERR "%s: Unable to identify device root port for card %d\n", DRV_NAME,
		       lro->instance);
		err = -EIO;
		goto done;
	}

	ep_name = pdev->bus->name;
#if defined(__PPC64__)
	printk(KERN_INFO "%s: Ignoring reset operation for card %d in slot %s:%02x:%1x\n", DRV_NAME, lro->instance, ep_name,
	       PCI_SLOT(pdev->devfn), PCI_FUNC(pdev->devfn));
#else
	printk(KERN_INFO "%s: Trying to reset card %d in slot %s:%02x:%1x\n", DRV_NAME, lro->instance, ep_name,
	       PCI_SLOT(pdev->devfn), PCI_FUNC(pdev->devfn));

	/* Allocate buffer for 256B PCIe config space */
	pci_cfg = kmalloc(0x100, GFP_KERNEL);
	if (!pci_cfg)
		return -ENOMEM;

	rp_name = pdev->bus->parent ? pdev->bus->parent->name : "null";
	/* Save the card's PCIe config space */

	for (i = 0; i < 0x100; i += 4) {
		pci_read_config_dword(pdev, i, &pci_cfg[i/4]);
	}

	pci_read_config_byte(pdev->bus->self, PCI_MIN_GNT, &hot);

	/* Toggle the PCIe hot reset bit in the root port */
	pci_write_config_byte(pdev->bus->self, PCI_MIN_GNT, hot | 0x40);

	ssleep(1);

	pci_write_config_byte(pdev->bus->self, PCI_MIN_GNT, hot);

	ssleep(1);

	/* Restore the card's PCIe config space */
	for (i = 0; i < 0x100; i += 4)
		pci_write_config_dword(pdev, i, pci_cfg[i/4]);

	ssleep(1);

	/* Verify we were able to restore card's PCIe config space */
	for (i = 0; i < 0x100; i += 4) {
		pci_read_config_dword(pdev, i, &pci_cfg2[i/4]);
		if (pci_cfg2[i/4] != pci_cfg[i/4])
			printk(KERN_WARNING "%s: Unable to restore config dword at %x (%x->%x) for card %d in slot %s:%02x:%1x\n",
			       DRV_NAME, i, pci_cfg[i/4], pci_cfg2[i/4], lro->instance, ep_name, PCI_SLOT(pdev->devfn),
			       PCI_FUNC(pdev->devfn));
	}

	err = reinit(lro);
	ssleep(1);
#endif
done:
	kfree(pci_cfg);
	return err;
}

/*
 * Based on Clocking Wizard v5.1, section Dynamic Reconfiguration through AXI4-Lite
 */
static long ocl_freqscaling_ioctl(struct xdma_char *lro_char, void __user *arg)
{
	struct xdma_ioc_freqscaling obj;
	struct xdma_dev *lro = lro_char->lro;
	long err = 0;
	int idx = 0;
	u32 val = 0;
	int i = 0;
	unsigned curr_freq;
	/* Divide by 1; multiply by 5 for Utrascale and 10 for V7 */
	u32 config = (lro->pci_dev->device == 0x8138) ? XDMA_KU3_CLKWIZ_CONFIG0 : XDMA_7V3_CLKWIZ_CONFIG0;

	if (copy_from_user((void *)&obj, arg, sizeof(struct xdma_ioc_freqscaling)))
		return -EFAULT;

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_STATUS);
	if ((val & 0x1) == 0)
		return -EBUSY;

	if (compute_unit_busy(lro))
		return -EBUSY;

	if ((obj.ocl_target_freq > 300) || (obj.ocl_target_freq < frequency_table[0].ocl))
		return -EINVAL;

	curr_freq = get_ocl_frequency(lro);

	idx = obj.ocl_target_freq / frequency_table[0].ocl;

	/* If current frequency is in the same step as the requested frequency then nothing to do */
	if (curr_freq / frequency_table[0].ocl == idx)
	    return 0;

	idx--;
	/*
	 * TODO:
	 * Need to lock the device so that another thread is not fiddling with the device at
	 * the same time, like downloading bitstream or starting kernel, etc.
	 */
	freezeAXIGate(lro);
	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(0));
	printk(KERN_INFO "%s: ClockWiz CONFIG(0) %x\n", DRV_NAME, val);

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(2));
	printk(KERN_INFO "%s: ClockWiz CONFIG(2) %x\n", DRV_NAME, val);

	val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_STATUS);
	if (val != 1) {
		err = -EBUSY;
		goto done;
	}

	config = frequency_table[idx].config0;
	iowrite32(config, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(0));
	config = frequency_table[idx].config2;
	iowrite32(config, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(2));
	msleep(10);
	iowrite32(0x00000007, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(23));
	msleep(1);
	iowrite32(0x00000002, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(23));
	printk(KERN_INFO "%s: ClockWiz waiting for locked signal\n", DRV_NAME);
	msleep(100);
	for (i = 0; i < 1000; i++) {
		val = ioread32(lro->bar[USER_BAR] + OCL_CLKWIZ_STATUS);
		if (val != 1) {
			msleep(100);
			continue;
		}
	}
	if (val != 1) {
		printk(KERN_ERR "%s: ClockWiz MMCM/PLL did not lock after %d ms, restoring the original configuration\n", DRV_NAME, 100 * 1000);
		/* restore the original clock configuration */
		iowrite32(0x00000004, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(23));
		msleep(10);
		iowrite32(0x00000000, lro->bar[USER_BAR] + OCL_CLKWIZ_CONFIG(23));
		err = -EINVAL;
	}

done:
	get_ocl_frequency(lro);
	freeAXIGate(lro);
	return err;
}


long char_ctrl_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct xdma_dev *lro;
	struct xdma_char *lro_char = (struct xdma_char *)filp->private_data;
	struct xdma_ioc_base ioctl_obj;
	long result = 0;
	BUG_ON(!lro_char);
	BUG_ON(lro_char->magic != MAGIC_CHAR);
	lro = lro_char->lro;
	BUG_ON(!lro);
	BUG_ON(lro->magic != MAGIC_DEVICE);

	printk(KERN_DEBUG "IOCTL %s:%d Command: %x\n", __FILE__, __LINE__, cmd);

	if (lro_char != lro->user_char_dev)
		return -ENOTTY;

	if (_IOC_TYPE(cmd) != XDMA_IOC_MAGIC)
		return -ENOTTY;

	if (_IOC_DIR(cmd) & _IOC_READ)
		result = !access_ok(VERIFY_WRITE, (void __user *)arg, _IOC_SIZE(cmd));
	else if (_IOC_DIR(cmd) & _IOC_WRITE)
		result =  !access_ok(VERIFY_READ, (void __user *)arg, _IOC_SIZE(cmd));

	if (result)
		return -EFAULT;

	printk(KERN_DEBUG "IOCTL %s:%d\n", __FILE__, __LINE__);
	if (copy_from_user((void *)&ioctl_obj, (void *) arg, sizeof(struct xdma_ioc_base)))
		return -EFAULT;
	if (ioctl_obj.magic != XDMA_XCL_MAGIC)
		return -ENOTTY;
	printk(KERN_DEBUG "IOCTL %s:%d\n", __FILE__, __LINE__);
	switch (cmd) {
	case XDMA_IOCINFO:
		return version_ioctl(lro_char, (void __user *)arg);
	case XDMA_IOCICAPDOWNLOAD:
	case XDMA_IOCMCAPDOWNLOAD:
		return bitstream_ioctl(lro_char, cmd, (void __user *)arg);
	case XDMA_IOCOCLRESET:
		return reset_ocl_ioctl(lro_char);
	case XDMA_IOCHOTRESET:
		return reset_hot_ioctl(lro_char);
	case XDMA_IOCFREQSCALING:
		return ocl_freqscaling_ioctl(lro_char, (void __user *)arg);
	case XDMA_IOCREBOOT:
		return pci_fundamental_reset(lro_char->lro);
	default:
		return -ENOTTY;
	}
	return 0;
}


long reset_device_if_running(struct xdma_dev *lro)
{
	/* If compute units are not busy then nothing to do */
	if (!compute_unit_busy(lro))
		return 0;

	/* If one or more compute units are busy then try to reset the card */
	printk(KERN_INFO "%s: One or more compute units busy\n", DRV_NAME);

	if (reset_ocl_ioctl(lro->user_char_dev) == 0)
		return 0;
	return reset_hot_ioctl(lro->user_char_dev);
}

// XSIP watermark, do not delete 67d7842dbbe25473c3c32b93c0da8047785f30d78e8a024de1b57352245f9689
